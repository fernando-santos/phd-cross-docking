
"Data200_a.txt": the coordinations and demands for the pickup and deliveries

First row:
number of customers, vehicle capacity, start time of the vehicles (6.00), finishing time of the vehicles (22.00), fixed time if a vehicle unoads/loads (in minute), time for unloading/loading each unit (in minute)

From the second row to the last one:
index, X_delivery, Y_delivery, X_pickup, Y_pickup, demand

Note: depot has index 0


"Data200_a_tw.txt": the TW corresponding to the requests in "Data200_a_txt"

Each row:
begin of delivery, end of delivery, begin of pickup, end of pickup


763 = 12:43 ; 883 = 14:43
